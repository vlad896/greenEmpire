export const SERVICESPAGE = [
  {
    image: '/assets/analitic/top-view-workmates-talking-about-bar-chart.webp',
    alt: 'Аналитика',
    h2: 'Аналитика',
    href: 'analitic',
  },
  {
    image: '/assets/analitic/close-up-glasses-annual-summary.webp',
    alt: 'Стратегия',
    h2: 'Стратегия',
    href: 'strategy',
  },
  {
    image: '/assets/analitic/close-up-financial-document-table.webp',
    alt: 'Дизайн',
    h2: 'Дизайн',
    href: 'design',
  },
  {
    image: '/assets/analitic/individuality-concept-silhouettes.webp',
    alt: 'Разработка сайта',
    h2: 'Разработка сайта',
    href: 'development',
  },
  {
    image: '/assets/analitic/individuality-concept-silhouettes.webp',
    alt: 'SMM',
    h2: 'SMM',
    href: 'smm',
  },
]
